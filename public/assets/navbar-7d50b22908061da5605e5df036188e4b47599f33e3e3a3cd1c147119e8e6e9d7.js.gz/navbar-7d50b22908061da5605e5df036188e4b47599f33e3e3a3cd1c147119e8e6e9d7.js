jQuery(function($) {
	$("li.nav-item a").on('click', function(e) {
		// Only called when clicking ona freshly loaded page!
	});
});

// console.log($(".nav").find(".active"));
// $(".nav").find(".active").removeClass("active");
// $(this).parent().addClass("active");
// console.log($(this));
