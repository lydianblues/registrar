jQuery(function($) {
	$('#students-table').DataTable();
	alert("Before datatables setup");
});
